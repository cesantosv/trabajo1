import FlashObject from 'ember-cli-flash/flash/object';

FlashObject.reopen({ init() {} });
