import Route from '@ember/routing/route';
import Ember from 'ember';
import Authenticated from '../mixins/authenticated-route';

export default Ember.Route.extend(Authenticated, {

});
