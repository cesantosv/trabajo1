import displayFlashErrors from 'trabajo1/utils/display-flash-errors';
import { module, test } from 'qunit';

module('Unit | Utility | display-flash-errors', function(hooks) {

  // Replace this with your real tests.
  test('it works', function(assert) {
    let result = displayFlashErrors();
    assert.ok(result);
  });
});
